insert into donors values('Bob', 'ForStart', 100);
insert into donors values('Bobby', 'ForStart', 100);
insert into donors values('Bobby', 'ForEnd', 100);